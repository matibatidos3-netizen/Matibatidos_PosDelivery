/**
 * MATIBATIDOS POS + MENÚ DIGITAL + DELIVERY
 * Vincular este script a la hoja "Matibatidos Online - Base de datos".
 * Conserva Pedidos y Detalle_pedidos. La pestaña Menu_Digital se crea de forma aditiva.
 */
function adminToken_() { return PropertiesService.getScriptProperties().getProperty('MATI_API_TOKEN') || ''; }
const SHEET_PEDIDOS = 'Pedidos';
const SHEET_DETALLE = 'Detalle_pedidos';
const SHEET_MENU = 'Menu_Digital';
const MENU_HEADERS = ['producto_id','nombre','categoria','descripcion','precio','imagen_url','visible','disponible','orden','actualizado_en'];

function doGet(e) {
  if (e && e.parameter && e.parameter.page === 'menu') {
    return HtmlService.createHtmlOutputFromFile('MenuDigital')
      .setTitle('Matibatidos | Menú digital')
      .addMetaTag('viewport', 'width=device-width, initial-scale=1');
  }
  return jsonOut_({ ok: true, service: 'Matibatidos Delivery API', version: '2.0-menu-digital' });
}

function doPost(e) {
  try {
    const body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    if (!adminToken_() || String(body.token || '') !== adminToken_()) return jsonOut_({ ok: false, error: 'No autorizado' });
    const action = String(body.action || '');
    if (action === 'ping') return jsonOut_({ ok: true, service: 'Matibatidos Delivery API', version: '2.0-menu-digital' });
    if (action === 'listPending') return jsonOut_(listPending_());
    if (action === 'getOrder') return jsonOut_(getOrder_(String(body.orderId || '')));
    if (action === 'markInvoiced') return jsonOut_(markInvoiced_(String(body.orderId || ''), String(body.invoice || '')));
    if (action === 'releaseOrder') return jsonOut_(releaseOrder_(String(body.orderId || '')));
    if (action === 'saveCatalog') return jsonOut_(saveCatalog_(body.products || []));
    if (action === 'initMenuDigital') return jsonOut_(initMenuDigital_());
    return jsonOut_({ ok: false, error: 'Acción no reconocida' });
  } catch (err) {
    return jsonOut_({ ok: false, error: String(err && err.message || err) });
  }
}

function jsonOut_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
function getSheetData_(name) {
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(name);
  if (!sh) throw new Error('No existe la pestaña ' + name);
  const values = sh.getDataRange().getValues();
  if (!values.length) throw new Error('La pestaña ' + name + ' está vacía');
  const headers = values[0].map(h => String(h).trim());
  const rows = values.slice(1).filter(r => r.some(v => v !== '' && v !== null));
  return { sheet: sh, headers, rows, index: Object.fromEntries(headers.map((h, i) => [h, i])) };
}
function val_(row, idx, key) { return idx[key] === undefined ? '' : row[idx[key]]; }
function bool_(v) { return v === true || String(v).toLowerCase() === 'true' || String(v) === '1'; }
function orderObject_(row, idx) {
  const obj = {};
  ['pedido_id','fecha','cliente_id','cliente_nombre','telefono','direccion','ubicacion','modalidad','zona_id','costo_delivery','estado_delivery','subtotal','total','metodo_pago','comentario','estado_pedido','facturado_pos','referencia_factura'].forEach(k => obj[k] = val_(row, idx, k));
  obj.facturado_pos = bool_(obj.facturado_pos);
  return obj;
}
function listPending_() {
  const d = getSheetData_(SHEET_PEDIDOS);
  const required = ['pedido_id','estado_pedido','facturado_pos'];
  required.forEach(k => { if (d.index[k] === undefined) throw new Error('Falta la columna ' + k + ' en Pedidos'); });
  const orders = d.rows.map(r => orderObject_(r, d.index)).filter(o => o.pedido_id && !o.facturado_pos && !['cancelado','anulado','rechazado'].includes(String(o.estado_pedido).toLowerCase()));
  orders.sort((a,b) => new Date(a.fecha || 0) - new Date(b.fecha || 0));
  return { ok: true, orders };
}
function getOrder_(orderId) {
  if (!orderId) throw new Error('Falta pedido_id');
  const p = getSheetData_(SHEET_PEDIDOS);
  const row = p.rows.find(r => String(val_(r,p.index,'pedido_id')) === orderId);
  if (!row) throw new Error('Pedido no encontrado: ' + orderId);
  const order = orderObject_(row,p.index);
  if (order.facturado_pos) return { ok: false, error: 'Este pedido ya fue facturado', order };
  const d = getSheetData_(SHEET_DETALLE);
  ['pedido_id','producto_nombre','cantidad','precio_unitario'].forEach(k => { if (d.index[k] === undefined) throw new Error('Falta la columna ' + k + ' en Detalle_pedidos'); });
  const items = d.rows.filter(r => String(val_(r,d.index,'pedido_id')) === orderId).map(r => ({
    detalle_id: val_(r,d.index,'detalle_id'), producto_id: val_(r,d.index,'producto_id'), producto_nombre: val_(r,d.index,'producto_nombre'),
    cantidad: Number(val_(r,d.index,'cantidad') || 0), precio_unitario: Number(val_(r,d.index,'precio_unitario') || 0),
    tipo_leche: val_(r,d.index,'tipo_leche'), azucar: val_(r,d.index,'azucar'), comentario: val_(r,d.index,'comentario'), total_linea: Number(val_(r,d.index,'total_linea') || 0)
  }));
  if (!items.length) throw new Error('El pedido no tiene productos en Detalle_pedidos');
  return { ok: true, order, items };
}
function markInvoiced_(orderId, invoice) {
  if (!orderId || !invoice) throw new Error('Se requiere pedido_id y número de factura');
  const lock = LockService.getScriptLock(); lock.waitLock(20000);
  try {
    const d = getSheetData_(SHEET_PEDIDOS);
    const idCol = d.index.pedido_id, billedCol = d.index.facturado_pos, refCol = d.index.referencia_factura, statusCol = d.index.estado_pedido;
    if (idCol === undefined || billedCol === undefined || refCol === undefined) throw new Error('Faltan columnas de facturación en Pedidos');
    const rowIndex = d.rows.findIndex(r => String(r[idCol]) === orderId);
    if (rowIndex < 0) throw new Error('Pedido no encontrado');
    const sheetRow = rowIndex + 2, already = bool_(d.rows[rowIndex][billedCol]), oldInvoice = String(d.rows[rowIndex][refCol] || '');
    if (already) { if (oldInvoice === invoice) return { ok: true, already: true, invoice }; return { ok: false, error: 'El pedido ya fue facturado con ' + oldInvoice }; }
    d.sheet.getRange(sheetRow, billedCol + 1).setValue(true);
    d.sheet.getRange(sheetRow, refCol + 1).setValue(invoice);
    if (statusCol !== undefined) d.sheet.getRange(sheetRow, statusCol + 1).setValue('facturado');
    SpreadsheetApp.flush(); return { ok: true, invoice };
  } finally { lock.releaseLock(); }
}
function releaseOrder_(orderId) { return { ok: true, orderId, message: 'El pedido permanece pendiente hasta facturarse' }; }

/** Crea únicamente Menu_Digital. Nunca edita ni reconstruye las hojas de pedidos. */
function initMenuDigital_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(SHEET_MENU);
  if (!sh) sh = ss.insertSheet(SHEET_MENU);
  if (sh.getLastRow() === 0) sh.getRange(1,1,1,MENU_HEADERS.length).setValues([MENU_HEADERS]);
  else {
    const existing = sh.getRange(1,1,1,Math.max(1,sh.getLastColumn())).getValues()[0].map(String);
    MENU_HEADERS.forEach(h => { if (existing.indexOf(h) < 0) { sh.getRange(1,sh.getLastColumn()+1).setValue(h); existing.push(h); } });
  }
  sh.setFrozenRows(1);
  return { ok:true, sheet:SHEET_MENU, headers:MENU_HEADERS };
}
function saveCatalog_(products) {
  if (!Array.isArray(products) || products.length > 500) throw new Error('Catálogo inválido o demasiado grande');
  initMenuDigital_();
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_MENU);
  const d = getSheetData_(SHEET_MENU);
  const rowsById = new Map(d.rows.map((r,i)=>[String(val_(r,d.index,'producto_id')),i+2]));
  const submittedIds = new Set(products.map(p=>String(p.producto_id||'').trim()).filter(Boolean));
  const now = new Date();
  // Si un producto fue eliminado del POS, deja de mostrarse públicamente sin borrar su historial.
  d.rows.forEach((r,i)=>{const id=String(val_(r,d.index,'producto_id'));if(id&&!submittedIds.has(id)){const rowNo=i+2;sh.getRange(rowNo,d.index.visible+1).setValue(false);}});
  products.forEach(p => {
    const id = String(p.producto_id || '').trim(), name = String(p.nombre || '').trim();
    if (!id || !name) return;
    const price = Number(p.precio);
    if (!Number.isFinite(price) || price < 0) throw new Error('Precio inválido para '+name);
    const row = {};
    row.producto_id=id; row.nombre=name; row.categoria=String(p.categoria||''); row.descripcion=String(p.descripcion||'').slice(0,500);
    row.precio=price; row.imagen_url=safeImageUrl_(p.imagen_url); row.visible=p.visible===true; row.disponible=p.disponible!==false;
    row.orden=Number(p.orden||0); row.actualizado_en=now;
    const values=d.headers.map(h=>row[h]===undefined?'':row[h]);
    const target=rowsById.get(id);
    if(target) sh.getRange(target,1,1,d.headers.length).setValues([values]);
    else sh.appendRow(values);
  });
  return {ok:true,count:products.length,sheet:SHEET_MENU};
}
function safeImageUrl_(url) {
  const s=String(url||'').trim();
  if (!s) return '';
  if (!/^https:\/\//i.test(s)) throw new Error('Las imágenes deben usar una URL HTTPS pública');
  return s;
}

/** Métodos públicos llamados desde HtmlService. Solo exponen productos publicados. */
function getPublicMenu() {
  const d=getSheetData_(SHEET_MENU);
  return d.rows.filter(r=>bool_(val_(r,d.index,'visible'))&&bool_(val_(r,d.index,'disponible'))).map(r=>({id:String(val_(r,d.index,'producto_id')),name:String(val_(r,d.index,'nombre')),category:String(val_(r,d.index,'categoria')),description:String(val_(r,d.index,'descripcion')),price:Number(val_(r,d.index,'precio')||0),image:String(val_(r,d.index,'imagen_url')),available:true,order:Number(val_(r,d.index,'orden')||0)}))
    .filter(p=>p.id&&p.name)
    .sort((a,b)=>a.order-b.order||a.category.localeCompare(b.category)||a.name.localeCompare(b.name));
}
function createPublicOrder(payload) {
  if (!payload || typeof payload !== 'object') throw new Error('Pedido inválido');
  const requestId=String(payload.requestId||'').trim();
  if(!/^[A-Za-z0-9_-]{8,80}$/.test(requestId))throw new Error('No se pudo validar el envío. Actualiza la página e intenta nuevamente.');
  // ID determinista: la misma solicitud siempre produce el mismo pedido_id.
  // La hoja Pedidos funciona como registro persistente; no depende de caché temporal.
  const digest=Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, requestId, Utilities.Charset.UTF_8);
  const requestHash=digest.map(b=>(b<0?b+256:b).toString(16).padStart(2,'0')).join('').slice(0,32).toUpperCase();
  const orderId='WEB-'+requestHash;
  const name=String(payload.customerName||'').trim(), phone=String(payload.phone||'').trim();
  const modality=String(payload.modality||'').toLowerCase(), payment=String(payload.payment||'').toLowerCase();
  const address=String(payload.address||'').trim(), note=String(payload.note||'').trim();
  if(name.length<2||phone.length<7)throw new Error('Escribe tu nombre y un teléfono válido.');
  if(!['delivery','pickup'].includes(modality))throw new Error('Selecciona entrega a domicilio o recoger en Matibatidos.');
  if(modality==='delivery'&&address.length<5)throw new Error('Escribe la dirección de entrega.');
  if(!['efectivo','transferencia'].includes(payment))throw new Error('Selecciona efectivo o transferencia.');
  if(!Array.isArray(payload.items)||!payload.items.length||payload.items.length>40)throw new Error('Agrega productos al pedido.');
  const menu=getPublicMenu(), byId=new Map(menu.map(p=>[p.id,p]));
  const items=payload.items.map(it=>{
    const p=byId.get(String(it.id||'')); const qty=Math.floor(Number(it.quantity||0));
    if(!p||!p.available)throw new Error('Uno de los productos ya no está disponible. Actualiza el menú.');
    if(qty<1||qty>30)throw new Error('Cantidad inválida para '+p.name);
    const milk=String(it.milk||'Entera').trim(), sugar=String(it.sugar||'Con azúcar').trim(), comment=String(it.comment||'').trim().slice(0,250);
    const allowedMilk=['Entera','Deslactosada','Almendras','Avena'];
    if(!allowedMilk.includes(milk))throw new Error('Tipo de leche no válido.');
    if(!['Con azúcar','Sin azúcar','Poca azúcar'].includes(sugar))throw new Error('Preferencia de azúcar no válida.');
    return {p,qty,milk,sugar,comment,line:Number((p.price*qty).toFixed(2))};
  });
  const subtotal=Number(items.reduce((sum,it)=>sum+it.line,0).toFixed(2));
  const fee=0; // La tarifa de envío se confirma con el cliente; no se inventa ni se cobra aquí.
  const total=Number((subtotal+fee).toFixed(2));
  const lock=LockService.getScriptLock();lock.waitLock(20000);
  try {
    const ss=SpreadsheetApp.getActiveSpreadsheet(), ps=ss.getSheetByName(SHEET_PEDIDOS), ds=ss.getSheetByName(SHEET_DETALLE);
    if(!ps||!ds)throw new Error('No se encuentran Pedidos y Detalle_pedidos. No se modificó el pedido.');
    const ph=ps.getRange(1,1,1,ps.getLastColumn()).getValues()[0].map(v=>String(v).trim());
    const dh=ds.getRange(1,1,1,ds.getLastColumn()).getValues()[0].map(v=>String(v).trim());
    const preq=['pedido_id','fecha','cliente_nombre','telefono','modalidad','estado_pedido','facturado_pos','subtotal','total','metodo_pago'];
    const dreq=['pedido_id','producto_nombre','cantidad','precio_unitario'];
    preq.forEach(k=>{if(!ph.includes(k))throw new Error('Falta la columna '+k+' en Pedidos. No se escribió nada.');});
    dreq.forEach(k=>{if(!dh.includes(k))throw new Error('Falta la columna '+k+' en Detalle_pedidos. No se escribió nada.');});
    if(modality==='delivery'&&!ph.includes('direccion'))throw new Error('Falta la columna direccion en Pedidos. No se escribió nada.');
    const existingRow=ps.getLastRow()>1?ps.getRange(2,ph.indexOf('pedido_id')+1,ps.getLastRow()-1,1).getDisplayValues().findIndex(r=>String(r[0])===orderId):-1;
    if(existingRow>=0){
      const existingData=ps.getRange(existingRow+2,1,1,ph.length).getValues()[0];
      const existingSubtotal=Number(existingData[ph.indexOf('subtotal')]||0), existingTotal=Number(existingData[ph.indexOf('total')]||0);
      const existingDetails=ds.getLastRow()>1?ds.getRange(2,dh.indexOf('pedido_id')+1,ds.getLastRow()-1,1).getDisplayValues().some(r=>String(r[0])===orderId):false;
      if(!existingDetails)throw new Error('La solicitud ya tiene un registro parcial. No se creó otro pedido; requiere revisión administrativa.');
      const previous={ok:true,orderId,total:existingTotal,subtotal:existingSubtotal,deliveryFee:0,already:true,message:'Este pedido ya había sido recibido.'};
      return previous;
    }
    const order={pedido_id:orderId,fecha:new Date(),cliente_nombre:name,telefono:phone,direccion:modality==='delivery'?address:'',ubicacion:modality==='delivery'?address:'',modalidad:modality==='delivery'?'delivery':'recoger',costo_delivery:fee,subtotal,total,metodo_pago:payment,comentario:note,estado_pedido:'pendiente',estado_delivery:'recibido',facturado_pos:false,referencia_factura:''};
    const prow=ph.map(h=>order[h]===undefined?'':order[h]);
    const detailRows=items.map(it=>{
      const details={pedido_id:orderId,detalle_id:Utilities.getUuid(),producto_id:it.p.id,producto_nombre:it.p.name,cantidad:it.qty,precio_unitario:it.p.price,tipo_leche:it.milk,azucar:it.sugar,comentario:it.comment,total_linea:it.line};
      return dh.map(h=>details[h]===undefined?'':details[h]);
    });
    const orderStartRow=ps.getLastRow()+1, detailStartRow=ds.getLastRow()+1;
    try {
      ps.getRange(orderStartRow,1,1,prow.length).setValues([prow]);
      ds.getRange(detailStartRow,1,detailRows.length,dh.length).setValues(detailRows);
      SpreadsheetApp.flush();
    } catch(writeError) {
      // Revierte únicamente las filas de esta solicitud si alguna escritura falla.
      if(ds.getLastRow()>=detailStartRow)ds.deleteRows(detailStartRow,Math.min(detailRows.length,ds.getLastRow()-detailStartRow+1));
      if(ps.getLastRow()>=orderStartRow)ps.deleteRow(orderStartRow);
      throw writeError;
    }
    const result={ok:true,orderId,total,subtotal,deliveryFee:fee,message:'Pedido recibido. El costo de envío se confirmará por WhatsApp.'};
    return result;
  } finally {lock.releaseLock();}
}
