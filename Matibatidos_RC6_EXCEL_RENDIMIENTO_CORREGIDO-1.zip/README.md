# Matibatidos POS RC6 — APK independiente

## Cambios de esta versión
- Importador compatible con el respaldo histórico `app/version/data.state` de Matibatidos.
- Recupera también las claves auxiliares de `data.storage`, usuarios y actividad.
- Identificador Android independiente: `com.matibatidos.pos.rc6`.
- Icono de la aplicación basado en el logo proporcionado de Matibatidos.
- Conserva el HTML funcional RC6 y los puentes Android incluidos en el proyecto.

## Compilación
Sube este ZIP completo, sin extraer, a la raíz del repositorio GitHub con el nombre exacto `Matibatidos_RC6_EXCEL_RENDIMIENTO_CORREGIDO.zip`. El workflow lo extrae automáticamente.
Después abre Actions > Matibatidos POS + Delivery - acceso corregido > Run workflow.
Descarga el artefacto `Matibatidos-POS-RC6-DELIVERY-MENU-1.2.4`.

## Importación del respaldo
En la nueva aplicación, inicia sesión con el usuario administrador que trae el respaldo y usa la opción Restaurar respaldo. La aplicación reconoce tanto `format: MATIBATIDOS_BACKUP` como el formato histórico que contiene `app`, `version` y `data.state`.

## Instalación independiente
La aplicación usa `applicationId` `com.matibatidos.pos.rc6`, diferente de `com.matibatidos.pos`; por tanto Android la instala como una aplicación separada. No desinstales la versión anterior.

## Precaución
La APK debug debe probarse en el dispositivo: restauración JSON, Excel, WhatsApp, permisos Bluetooth, impresora y respaldo externo. Mantén una copia adicional del JSON original.


## Correcciones RC6: Excel y rendimiento

- Se mantiene el identificador independiente `com.matibatidos.pos.rc6`.
- Se mantiene la estructura de datos y el formato de respaldo JSON.
- El flujo de GitHub Actions incorpora localmente SheetJS 0.20.3 y Chart.js 4.4.7 dentro de `app/src/main/assets`, para que Excel y gráficos no dependan de una descarga en tiempo de ejecución.
- El guardado nativo de archivos informa el resultado y escribe en `Descargas/Matibatidos` mediante MediaStore en Android 10 o superior.
- El caché de imágenes usa URLs temporales de Blob en lugar de conservar cadenas Base64 completas.
- Al iniciar, solo se precargan las imágenes referenciadas por los productos y el logo; las imágenes huérfanas no se borran del IndexedDB.
- No se vacía IndexedDB ni localStorage y no se cambia el esquema del respaldo.

Para compilar, utiliza `.github/workflows/build-apk.yml`. El workflow espera que el ZIP original esté en la raíz del repositorio con su nombre exacto:
`Matibatidos_RC6_EXCEL_RENDIMIENTO_CORREGIDO.zip`.


Menú digital: revisar `GUIA_INTEGRACION_DELIVERY.md`, `Api_Matibatidos_Delivery.gs` y `MenuDigital.html`.
