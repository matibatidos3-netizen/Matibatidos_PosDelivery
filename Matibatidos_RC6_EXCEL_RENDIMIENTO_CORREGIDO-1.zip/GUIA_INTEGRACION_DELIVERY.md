# Matibatidos RC6 - Menú digital + Delivery

## Cambios incluidos
- Se conserva el POS RC6 y el identificador `com.matibatidos.pos.rc6`.
- Se corrige el cierre de etiqueta `script` dentro del HTML de impresión que podía truncar el JavaScript principal.
- Se agrega el módulo **Menú digital** al POS. Solo Administrador puede publicar; el catálogo fuente sigue siendo `Productos` del POS.
- Se agrega `Menu_Digital` de forma aditiva. `Pedidos` y `Detalle_pedidos` no se borran, renombran ni reconstruyen.
- Se agrega una página web de clientes servida por Apps Script (`?page=menu`), con delivery/recoger, efectivo/transferencia, leche, azúcar y comentarios.
- Los pedidos públicos se guardan en las hojas existentes `Pedidos` y `Detalle_pedidos`. No hay descuento de inventario al recibir o aceptar. El POS mantiene la facturación como único punto de descuento.
- Las imágenes públicas se guardan como URL HTTPS. No se suben imágenes Base64 del almacenamiento local del POS.

## Paso 1 - Actualizar Apps Script sin tocar los datos
1. Abre la hoja `Matibatidos Online - Base de datos`.
2. En **Extensiones > Apps Script**, abre el proyecto vinculado.
3. Reemplaza el contenido de `Code.gs` con `Api_Matibatidos_Delivery.gs` incluido en este ZIP.
4. En Apps Script, abre **Configuración del proyecto > Propiedades del script** y agrega `MATI_API_TOKEN` con la clave administrativa que ya usas en la conexión Delivery de RC6. No pegues esa clave en páginas públicas ni la compartas.
5. Crea un archivo HTML llamado exactamente `MenuDigital` y pega el contenido de `MenuDigital.html` incluido en este ZIP.
6. Guarda. Ejecuta una vez la función `initMenuDigital_` desde el editor y concede permisos. Esto crea solamente la pestaña `Menu_Digital`; si ya existe, agrega encabezados faltantes sin borrar filas. Verifica que `Pedidos` y `Detalle_pedidos` sigan presentes.
7. En **Implementar > Administrar implementaciones**, edita la implementación web existente para usar la nueva versión. Mantén el mismo URL `/exec` para no perder la configuración guardada en RC6. Ejecutar como: tú. Acceso: cualquier persona (la página de cliente necesita acceso público; las acciones administrativas se validan con la propiedad secreta).

> Importante: el token administrativo anterior estaba incrustado en el JavaScript de la APK. En esta versión del servidor el secreto se lee desde Propiedades del script, no desde el archivo fuente del servidor. Para una seguridad completa, después de validar esta migración hay que rotar la clave y actualizarla en la configuración de la APK. No publiques el token en capturas ni mensajes.

## Paso 2 - Publicar el menú desde el POS
1. Abre RC6 y entra como Administrador.
2. Entra en **Mesas > Conexión** y confirma la URL `/exec` y la clave administrativa. Pulsa **Probar conexión**.
3. Abre **Menú digital** en el menú lateral.
4. Marca **Mostrar en menú** solo para productos que quieras publicar. Desmarca **Disponible** cuando se agoten temporalmente.
5. Agrega una descripción y una URL HTTPS pública para la foto si la tienes. Las fotos locales del POS no se publican automáticamente.
6. Pulsa **Guardar y publicar**.

## Paso 3 - Enlace de clientes
El enlace web será la URL de la implementación seguida de `?page=menu`, por ejemplo `https://script.google.com/macros/s/ID_DE_IMPLEMENTACION/exec?page=menu`. Puedes convertirlo en QR para mesas, mostrador y redes sociales. El mismo enlace puede abrirse en navegador móvil.

## Reglas de pedido y entrega
- Modalidades: `delivery` y `recoger`.
- Pago: `efectivo` o `transferencia`.
- La dirección es obligatoria solo para delivery.
- Leche: Entera, Deslactosada, Almendras o Avena. Azúcar: Con azúcar, Sin azúcar o Poca azúcar.
- El costo de envío queda en C$0 en el registro inicial y se confirma por WhatsApp; no se inventa una tarifa. Antes de operar delivery pagado, debe configurarse una tabla de zonas/tarifas y probar su cálculo.
- El menú valida precio y disponibilidad en el servidor al enviar el pedido; no confía en el precio enviado por el teléfono. Cada envío lleva un identificador de solicitud para que un reintento no cree un segundo pedido.
- La API comprueba encabezados requeridos en las dos hojas antiguas antes de escribir. Si falta una columna, aborta antes de escribir el pedido y muestra el nombre de la columna faltante.
- `facturado_pos` inicia en FALSE. Recibir el pedido no descuenta existencias. El descuento ocurre al facturar en el POS, usando las recetas locales.

## Pruebas obligatorias antes de producción
1. Ejecutar `initMenuDigital_` y verificar que se creó solo `Menu_Digital`.
2. Publicar un solo producto de prueba desde RC6.
3. Abrir `/exec?page=menu` y comprobar que solo aparece el producto publicado.
4. Enviar pedido de recogida y revisar `Pedidos` y `Detalle_pedidos`.
5. Enviar pedido delivery sin dirección: debe rechazarse. Con dirección: debe registrarse.
6. Confirmar que el pedido aparece en Mesas > Delivery, con personalizaciones y totales correctos.
7. Confirmar que las existencias no cambian al recibir/abrir el pedido.
8. Reenviar la misma solicitud de prueba (si se interrumpe la respuesta) y comprobar que conserva el mismo número de pedido y no duplica filas.
9. Facturar una sola vez y comprobar un único descuento de receta y `facturado_pos=TRUE`.
10. Reintentar la sincronización y comprobar que no se duplica la factura.

## Limitaciones pendientes
- Esta entrega incluye el menú web responsive. No incluye todavía una APK cliente independiente; se debe empaquetar después de validar el flujo web y el backend, con identificador separado `com.matibatidos.clientes`.
- El menú usa URL pública HTTPS para imágenes. Para mostrar imágenes locales del POS primero hay que subirlas a almacenamiento público (por ejemplo Drive con permisos de lectura) y guardar la URL resultante.
- La tarifa de delivery no se calcula todavía por zona. La página advierte que se confirma por WhatsApp y no la suma al total inicial.
- El esquema real de las hojas debe comprobarse en la primera prueba; si falta una columna obligatoria, el servidor se detiene sin escribir.
